import {
  getMovieById,
  getMovies,
  getMovieByMinimumRating,
  getMovieByMinimumYear
} from "./db";

export const home = (req, res) => {
  const movies = getMovies();
  return res.render("home", { pageTitle: "Movies!", movies });
};
export const movieDetail = (req, res) => {
  const { id } = req.params;
  const movie = getMovieById(id);
  const movieTitle = movie.title;
  return res.render("movieDetail", { pageTitle: `${movieTitle}`, movie });
};

export const filterMovie = (req, res) => {
  const { year, rating } = req.query;
  try {
    const movies = year
      ? getMovieByMinimumYear(year)
      : getMovieByMinimumRating(rating);
    console.log(movies[0].id);
    return res.render("filter", {
      pageTitle: `Searching By ${year ? "year" : "rating"} : ${
        year ? year : rating
      }`,
      movies
    });
  } catch (error) {
    res.redirect("/");
  }
};
