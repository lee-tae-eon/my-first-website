const fakeUser = {
  username: "Lee",
  loggedIn: true
};

export const join = (req, res) =>
  res.render("join", { pageTitle: "Join", fakeUser });
export const login = (req, res) =>
  res.render("login", { pageTitle: "Log In", fakeUser });
export const seeUsers = (req, res) =>
  res.render("seeUsers", { pageTitle: "See User", fakeUser });
export const seeUser = (req, res) => {
  const userProfile = req.params.id;
  res.render("seeUser", { pageTitle: "User Profile", userProfile, fakeUser });
};
export const editProfile = (req, res) =>
  res.render("editProfile", { pageTitle: "Edit Profile", fakeUser });
