const fakeUser = {
  username: "Lee",
  loggedIn: true
};

export const home = (req, res) =>
  res.render("home", { pageTitle: "Home", fakeUser });
export const trending = (req, res) => {
  const storyList = [
    "javscript",
    "ES6",
    "WeTube",
    "CocoaClone",
    "VanillaJS",
    "NestJS API",
    "tweeter clone",
    "web scrapper with python",
    "React Js for beginner",
    "CSS Master Class",
    "Git & GitHub for Everyone"
  ];
  res.render("trending", { pageTitle: "trending", storyList, fakeUser });
};
export const newStories = (req, res) => {
  const newStoryList = [
    "Gulp Master",
    "Create Movie App with GraphQL",
    "Selenium for beginner",
    "Create BlockChain with TypeScript",
    "Redux 101 for beginner",
    "Create whether App with React native"
  ];
  res.render("newStories", { pageTitle: "newStory", newStoryList, fakeUser });
};
export const seeStory = (req, res) => {
  const storyNumber = req.params.id;
  res.render("seeStory", { pageTitle: "seeStory", storyNumber, fakeUser });
};
export const editStory = (req, res) => {
  const storyNumber = req.params.id;
  res.render("editStory", { pageTitle: "Edit Story", storyNumber, fakeUser });
};
export const deleteStory = (req, res) => {
  const storyNumber = req.params.id;
  res.render("deleteStory", {
    pageTitle: "Delete Story",
    storyNumber,
    fakeUser
  });
};
