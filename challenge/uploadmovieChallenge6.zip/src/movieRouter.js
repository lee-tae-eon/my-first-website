import express from "express";
import {
  home,
  movieDetail,
  getUploadMovie,
  postUploadMovie
} from "./movieController";

const movieRouter = express.Router();

movieRouter.get("/", home);
movieRouter.route("/add").get(getUploadMovie).post(postUploadMovie);
movieRouter.get("/:id", movieDetail);

// create the /add route (GET + POST)

export default movieRouter;
