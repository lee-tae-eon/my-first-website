import { getMovieById, getMovies, addMovie } from "./db";

export const home = (req, res) =>
  res.render("movies", { movies: getMovies(), pageTitle: "Movies!" });

export const movieDetail = (req, res) => {
  const {
    params: { id }
  } = req;
  const movie = getMovieById(id);
  if (!movie) {
    res.render("404", { pageTitle: "Movie not found" });
  }
  return res.render("detail", { movie });
};

/*
Write the controller or controllers you need to render the form
and to handle the submission
*/

export const getUploadMovie = (req, res) =>
  res.render("upload", { pageTitle: "Add Movie" });

export const postUploadMovie = (req, res) => {
  let { title, synopsis, genres } = req.body;
  genres = genres.split(",");
  const newMovie = { title, synopsis, genres };

  addMovie(newMovie);

  return res.redirect("/");
};
